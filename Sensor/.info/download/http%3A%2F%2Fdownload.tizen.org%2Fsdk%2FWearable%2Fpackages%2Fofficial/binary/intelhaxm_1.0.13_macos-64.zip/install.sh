#!/bin/sh -x

do_unmount()
{
	MOUNTED_HAXM=`ls /Volumes/ | grep 'IntelHAXM'`
	if [ "${MOUNTED_HAXM}" != "" ]
	then
		echo "unmount IntelHaxmTizen.dmg"
		ls /Volumes/ | grep 'IntelHAXM'	| awk '{system("hdiutil unmount /Volumes/" $0)}'
	fi
}

TIZEN_SDK_INSTALL_PATH=`echo ${INSTALLED_PATH}`
if [ -z ${TIZEN_SDK_INSTALL_PATH} ]
then
   echo "There is no TIZEN_SDK_PATH ENV" >> /tmp/emulator.log
   exit 2;
fi

COCOASUDO_BIN_PATH=${TIZEN_SDK_INSTALL_PATH}/tools/emulator/bin/cocoasudo
INTELHAXM_BIN_PATH=${TIZEN_SDK_INSTALL_PATH}/tools/emulator/etc/IntelHaxmTizen.dmg
if [ -e ${INTELHAXM_BIN_PATH} ]
then
	do_unmount

	echo "mount IntelHaxmTizen.dmg"
	hdiutil mount ${INTELHAXM_BIN_PATH}

	INTELHAXM_PKG_PATH=`ls /Volumes/IntelHAXM*/*.mpkg`
	if [ "${INTELHAXM_PKG_PATH}" = "" ]
	then
		echo "cannot find IntelHAXM mpkg file!!"
		exit 0;
	fi

	echo "install IntelHaxmTizen"
	if [ -e ${COCOASUDO_BIN_PATH} ]
	then
		if [ -x ${COCOASUDO_BIN_PATH} ]
		then
			${COCOASUDO_BIN_PATH} installer -pkg ${INTELHAXM_PKG_PATH} -target /
		else
			echo "cocoasudo is not executable."
		fi
	else
		echo "cocoasudo does not exist."
	fi

	do_unmount
fi
